import fastf1
import pandas as pd
import numpy as np
from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from sklearn.model_selection import train_test_split
import warnings
import asyncio
import aiohttp
import json
from datetime import datetime, timedelta
import logging
from typing import Dict, List, Optional, Tuple
import pickle
import os

warnings.filterwarnings('ignore')

# Set up logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

class AdvancedLapPredictor:
    def __init__(self, cache_dir='cache'):
        self.models = {}
        self.scalers = {}
        self.label_encoders = {}
        self.history_data = {}
        self.live_data = {}
        self.telemetry_data = {}
        self.weather_data = {}
        self.cache_dir = cache_dir
        self.session_cache = {}
        
        # Create cache directory
        os.makedirs(cache_dir, exist_ok=True)
        
        # Enable FastF1 cache
        fastf1.Cache.enable_cache(cache_dir)
        
        # Initialize ML models
        self.initialize_models()
    
    def initialize_models(self):
        """Initialize multiple ML models for different prediction scenarios"""
        self.model_types = {
            'lap_time': RandomForestRegressor(n_estimators=200, random_state=42, max_depth=15),
            'sector_1': GradientBoostingRegressor(n_estimators=100, random_state=42),
            'sector_2': GradientBoostingRegressor(n_estimators=100, random_state=42),
            'sector_3': GradientBoostingRegressor(n_estimators=100, random_state=42),
            'tyre_degradation': RandomForestRegressor(n_estimators=150, random_state=42)
        }
        
        # Initialize label encoders
        self.label_encoders['compound'] = LabelEncoder()
        self.label_encoders['team'] = LabelEncoder()
    
    async def fetch_session_data(self, year: int, event_name: str, session_type: str, force_refresh: bool = False) -> Optional[fastf1.core.Session]:
        """Fetch session data with caching and async support"""
        cache_key = f"{year}_{event_name}_{session_type}"
        
        if not force_refresh and cache_key in self.session_cache:
            logger.info(f"Using cached session data for {cache_key}")
            return self.session_cache[cache_key]
        
        try:
            logger.info(f"Fetching session data for {year} {event_name} {session_type}")
            
            # Get session
            session = fastf1.get_session(year, event_name, session_type)
            
            # Load session data with progress indication
            session.load(telemetry=False, weather=False, messages=False)
            
            # Cache the session
            self.session_cache[cache_key] = session
            self.history_data[cache_key] = session.laps
            
            logger.info(f"Successfully loaded session with {len(session.laps)} laps")
            return session
            
        except Exception as e:
            logger.error(f"Error fetching session data: {e}")
            return None
    
    def enhanced_preprocess_lap_data(self, laps_data: pd.DataFrame, driver: str = None) -> Tuple[pd.DataFrame, pd.Series]:
        """Enhanced preprocessing with more features and telemetry integration"""
        if driver:
            laps = laps_data.pick_driver(driver)
        else:
            laps = laps_data
        
        if len(laps) == 0:
            return pd.DataFrame(), pd.Series()
        
        features = []
        targets = []
        
        for _, lap in laps.iterrows():
            if pd.isna(lap['LapTime']) or pd.isna(lap['LapNumber']):
                continue
            
            # Basic lap features
            feature_dict = {
                'lap_number': lap['LapNumber'],
                'stint': lap.get('Stint', 1),
                'position': lap.get('Position', 10),
                'tyre_age': self._calculate_tyre_age(laps, lap),
                'compound_encoded': self._encode_tyre(lap.get('Compound', 'MEDIUM')),
                'team_encoded': self._encode_team(lap.get('Team', 'Unknown')),
            }
            
            # Track conditions
            feature_dict.update({
                'track_temp': lap.get('TrackTemp', 25),
                'air_temp': lap.get('AirTemp', 25),
                'humidity': lap.get('Humidity', 50),
            })
            
            # Sector times
            for i in range(1, 4):
                sector_key = f'Sector{i}Time'
                if sector_key in lap and not pd.isna(lap[sector_key]):
                    feature_dict[f'sector_{i}'] = lap[sector_key].total_seconds()
                else:
                    feature_dict[f'sector_{i}'] = 0
            
            # Lap time statistics
            feature_dict.update({
                'lap_time_seconds': lap['LapTime'].total_seconds() if hasattr(lap['LapTime'], 'total_seconds') else lap['LapTime'],
                'is_personal_best': lap.get('IsPersonalBest', False),
                'is_fastest_lap': lap.get('IsFastestLap', False),
            })
            
            # Calculate rolling averages (simplified)
            if lap.name > 0:
                previous_laps = laps.iloc[max(0, lap.name-3):lap.name]
                if len(previous_laps) > 0:
                    feature_dict['avg_previous_3'] = previous_laps['LapTime'].apply(
                        lambda x: x.total_seconds() if hasattr(x, 'total_seconds') else x
                    ).mean()
                else:
                    feature_dict['avg_previous_3'] = feature_dict['lap_time_seconds']
            else:
                feature_dict['avg_previous_3'] = feature_dict['lap_time_seconds']
            
            features.append(feature_dict)
            
            # Target: next lap time (for prediction)
            if lap.name < len(laps) - 1:
                next_lap = laps.iloc[lap.name + 1]
                if not pd.isna(next_lap['LapTime']):
                    target_time = next_lap['LapTime'].total_seconds() if hasattr(next_lap['LapTime'], 'total_seconds') else next_lap['LapTime']
                    targets.append(target_time)
                else:
                    targets.append(feature_dict['lap_time_seconds'])
            else:
                targets.append(feature_dict['lap_time_seconds'])
        
        # Ensure we have the same number of features and targets
        min_length = min(len(features), len(targets))
        features = features[:min_length]
        targets = targets[:min_length]
        
        return pd.DataFrame(features), pd.Series(targets)
    
    def _encode_tyre(self, compound: str) -> int:
        """Encode tyre compound with more granularity"""
        tyre_map = {
            'SOFT': 3, 'MEDIUM': 2, 'HARD': 1,
            'INTERMEDIATE': 4, 'WET': 5,
            'C1': 1, 'C2': 2, 'C3': 3, 'C4': 4, 'C5': 5
        }
        return tyre_map.get(compound.upper(), 0)
    
    def _encode_team(self, team: str) -> int:
        """Encode team name"""
        try:
            return self.label_encoders['team'].fit_transform([team])[0]
        except:
            return 0
    
    def _calculate_tyre_age(self, laps: pd.DataFrame, current_lap: pd.Series) -> int:
        """Calculate tyre age considering stint information"""
        try:
            stint = current_lap['Stint']
            current_lap_num = current_lap['LapNumber']
            
            # Find laps in same stint
            stint_laps = laps[laps['Stint'] == stint]
            if len(stint_laps) == 0:
                return 1
            
            # Sort by lap number and find current lap position
            stint_laps = stint_laps.sort_values('LapNumber')
            for i, (_, lap) in enumerate(stint_laps.iterrows()):
                if lap['LapNumber'] == current_lap_num:
                    return i + 1
            
            return 1
        except Exception as e:
            logger.warning(f"Error calculating tyre age: {e}")
            return 1
    
    def train_advanced_model(self, year: int, event_name: str, session_type: str, driver: str = None):
        """Train advanced ML model with multiple features"""
        cache_key = f"{year}_{event_name}_{session_type}_{driver if driver else 'all'}"
        
        try:
            # Get session data
            session = asyncio.run(self.fetch_session_data(year, event_name, session_type))
            if session is None:
                logger.error("Failed to fetch session data")
                return None
            
            # Preprocess data
            X, y = self.enhanced_preprocess_lap_data(session.laps, driver)
            
            if len(X) < 10:
                logger.warning("Not enough data for training")
                return None
            
            # Split data
            X_train, X_test, y_train, y_test = train_test_split(
                X, y, test_size=0.2, random_state=42, shuffle=False
            )
            
            # Scale features
            scaler = StandardScaler()
            X_train_scaled = scaler.fit_transform(X_train)
            X_test_scaled = scaler.transform(X_test)
            
            # Train model
            model = self.model_types['lap_time']
            model.fit(X_train_scaled, y_train)
            
            # Store model and scaler
            self.models[cache_key] = model
            self.scalers[cache_key] = scaler
            
            # Evaluate model
            train_score = model.score(X_train_scaled, y_train)
            test_score = model.score(X_test_scaled, y_test)
            y_pred = model.predict(X_test_scaled)
            mae = mean_absolute_error(y_test, y_pred)
            rmse = np.sqrt(mean_squared_error(y_test, y_pred))
            
            logger.info(f"Model trained for {cache_key}")
            logger.info(f"Train R²: {train_score:.3f}, Test R²: {test_score:.3f}")
            logger.info(f"MAE: {mae:.3f}s, RMSE: {rmse:.3f}s")
            
            # Save model
            self.save_model(cache_key)
            
            return model
            
        except Exception as e:
            logger.error(f"Error training model: {e}")
            return None
    
    def predict_next_lap_advanced(self, current_lap_data: dict, year: int, event_name: str, 
                                session_type: str, driver: str = None) -> Dict:
        """Advanced next lap prediction with confidence intervals"""
        cache_key = f"{year}_{event_name}_{session_type}_{driver if driver else 'all'}"
        
        if cache_key not in self.models:
            logger.info("Model not trained. Training now...")
            self.train_advanced_model(year, event_name, session_type, driver)
        
        if cache_key not in self.models:
            return None
        
        try:
            # Prepare features for prediction
            features = self._prepare_advanced_features(current_lap_data)
            if features is None:
                return None
            
            # Scale features and predict
            scaler = self.scalers[cache_key]
            model = self.models[cache_key]
            
            features_scaled = scaler.transform([features])
            predicted_time = model.predict(features_scaled)[0]
            
            # Calculate confidence (simplified - in production, use proper uncertainty quantification)
            confidence = self._calculate_prediction_confidence(model, features_scaled)
            
            # Predict sectors
            sector_predictions = self._predict_sectors(current_lap_data, predicted_time)
            
            return {
                'predicted_lap_time': predicted_time,
                'predicted_sectors': sector_predictions,
                'confidence': confidence,
                'timestamp': datetime.now(),
                'features_used': list(features.keys())
            }
            
        except Exception as e:
            logger.error(f"Error in prediction: {e}")
            return None
    
    def _prepare_advanced_features(self, lap_data: dict) -> Optional[List]:
        """Prepare advanced features for prediction"""
        try:
            features = {
                'lap_number': lap_data.get('LapNumber', 1) + 1,
                'stint': lap_data.get('Stint', 1),
                'position': lap_data.get('Position', 10),
                'tyre_age': lap_data.get('tyre_age', 1) + 1,
                'compound_encoded': self._encode_tyre(lap_data.get('Compound', 'MEDIUM')),
                'team_encoded': self._encode_team(lap_data.get('Team', 'Unknown')),
                'track_temp': lap_data.get('TrackTemp', 25),
                'air_temp': lap_data.get('AirTemp', 25),
                'humidity': lap_data.get('Humidity', 50),
                'avg_previous_3': lap_data.get('avg_previous_laps', 0),
            }
            
            # Add sector times
            for i in range(1, 4):
                sector_key = f'Sector{i}Time'
                if sector_key in lap_data and not pd.isna(lap_data[sector_key]):
                    features[f'sector_{i}'] = lap_data[sector_key]
                else:
                    features[f'sector_{i}'] = 0
            
            return list(features.values())
            
        except Exception as e:
            logger.error(f"Error preparing features: {e}")
            return None
    
    def _predict_sectors(self, current_lap_data: dict, total_predicted_time: float) -> Dict:
        """Predict individual sector times"""
        try:
            # Simple proportional prediction based on current lap sectors
            sectors = {}
            total_current = 0
            
            for i in range(1, 4):
                sector_key = f'Sector{i}Time'
                if sector_key in current_lap_data:
                    sectors[f'sector_{i}'] = current_lap_data[sector_key]
                    total_current += current_lap_data[sector_key]
                else:
                    sectors[f'sector_{i}'] = 0
            
            if total_current > 0:
                # Scale sectors proportionally to predicted total
                scale_factor = total_predicted_time / total_current
                for i in range(1, 4):
                    sectors[f'sector_{i}'] *= scale_factor
            
            return sectors
            
        except Exception as e:
            logger.error(f"Error predicting sectors: {e}")
            return {f'sector_{i}': total_predicted_time / 3 for i in range(1, 4)}
    
    def _calculate_prediction_confidence(self, model, features: np.ndarray) -> float:
        """Calculate prediction confidence (simplified version)"""
        try:
            # Use model's prediction probability or uncertainty
            if hasattr(model, 'predict_proba'):
                # For classifiers that have probability
                proba = model.predict_proba(features)
                confidence = np.max(proba[0])
            else:
                # For regressors, use inverse of normalized standard deviation (simplified)
                predictions = []
                if hasattr(model, 'estimators_'):
                    # For ensemble methods, use estimator predictions
                    for estimator in model.estimators_:
                        predictions.append(estimator.predict(features)[0])
                    std_dev = np.std(predictions)
                    confidence = max(0, 1 - (std_dev / np.mean(predictions)))
                else:
                    # Default confidence
                    confidence = 0.85
            
            return min(0.99, max(0.1, confidence))
            
        except:
            return 0.8  # Default confidence
    
    def real_time_analysis(self, session: fastf1.core.Session, driver: str, window_size: int = 10):
        """Perform real-time analysis on driver's laps"""
        try:
            driver_laps = session.laps.pick_driver(driver)
            if len(driver_laps) < 5:
                logger.warning(f"Not enough laps for driver {driver}")
                return None
            
            analysis_results = {
                'driver': driver,
                'total_laps': len(driver_laps),
                'best_lap': None,
                'average_lap': None,
                'consistency': None,
                'tyre_performance': {},
                'stint_analysis': {},
                'predictions': []
            }
            
            # Calculate basic statistics
            lap_times = []
            for _, lap in driver_laps.iterrows():
                if not pd.isna(lap['LapTime']):
                    lap_time = lap['LapTime'].total_seconds() if hasattr(lap['LapTime'], 'total_seconds') else lap['LapTime']
                    lap_times.append(lap_time)
            
            if lap_times:
                analysis_results['best_lap'] = min(lap_times)
                analysis_results['average_lap'] = np.mean(lap_times)
                analysis_results['consistency'] = np.std(lap_times)
            
            # Analyze tyre performance
            compounds = driver_laps['Compound'].unique()
            for compound in compounds:
                if pd.isna(compound):
                    continue
                compound_laps = driver_laps[driver_laps['Compound'] == compound]
                compound_times = []
                for _, lap in compound_laps.iterrows():
                    if not pd.isna(lap['LapTime']):
                        lap_time = lap['LapTime'].total_seconds() if hasattr(lap['LapTime'], 'total_seconds') else lap['LapTime']
                        compound_times.append(lap_time)
                
                if compound_times:
                    analysis_results['tyre_performance'][compound] = {
                        'average_time': np.mean(compound_times),
                        'best_time': min(compound_times),
                        'lap_count': len(compound_times)
                    }
            
            # Generate predictions for recent laps
            recent_laps = driver_laps.tail(min(window_size, len(driver_laps)))
            for i, (_, lap) in enumerate(recent_laps.iterrows()):
                if i < len(recent_laps) - 1:  # Don't predict for the last lap
                    prediction = self.predict_next_lap_advanced(
                        lap.to_dict(), session.event.year, session.event.EventName, session.name, driver
                    )
                    if prediction:
                        analysis_results['predictions'].append({
                            'lap_number': lap['LapNumber'],
                            'prediction': prediction
                        })
            
            return analysis_results
            
        except Exception as e:
            logger.error(f"Error in real-time analysis: {e}")
            return None
    
    def compare_drivers(self, session: fastf1.core.Session, drivers: List[str]) -> Dict:
        """Compare multiple drivers' performance"""
        comparison = {
            'session_info': {
                'year': session.event.year,
                'event': session.event.EventName,
                'session': session.name
            },
            'drivers': {}
        }
        
        for driver in drivers:
            analysis = self.real_time_analysis(session, driver)
            if analysis:
                comparison['drivers'][driver] = analysis
        
        return comparison
    
    def save_model(self, model_key: str):
        """Save trained model to disk"""
        try:
            model_path = os.path.join(self.cache_dir, f"{model_key}_model.pkl")
            scaler_path = os.path.join(self.cache_dir, f"{model_key}_scaler.pkl")
            
            with open(model_path, 'wb') as f:
                pickle.dump(self.models[model_key], f)
            
            with open(scaler_path, 'wb') as f:
                pickle.dump(self.scalers[model_key], f)
            
            logger.info(f"Model saved for {model_key}")
            
        except Exception as e:
            logger.error(f"Error saving model: {e}")
    
    def load_model(self, model_key: str) -> bool:
        """Load trained model from disk"""
        try:
            model_path = os.path.join(self.cache_dir, f"{model_key}_model.pkl")
            scaler_path = os.path.join(self.cache_dir, f"{model_key}_scaler.pkl")
            
            if os.path.exists(model_path) and os.path.exists(scaler_path):
                with open(model_path, 'rb') as f:
                    self.models[model_key] = pickle.load(f)
                
                with open(scaler_path, 'rb') as f:
                    self.scalers[model_key] = pickle.load(f)
                
                logger.info(f"Model loaded for {model_key}")
                return True
            
            return False
            
        except Exception as e:
            logger.error(f"Error loading model: {e}")
            return False
    
    def get_driver_telemetry(self, session: fastf1.core.Session, driver: str, lap_number: int = None):
        """Get detailed telemetry data for a driver"""
        try:
            if lap_number:
                lap = session.laps.pick_driver(driver).pick_lap(lap_number)
            else:
                lap = session.laps.pick_driver(driver).iloc[-1]  # Most recent lap
            
            if lap is None or pd.isna(lap):
                return None
            
            # Load telemetry for the lap
            tel = lap.get_telemetry()
            
            telemetry_data = {
                'lap_number': lap['LapNumber'],
                'driver': driver,
                'lap_time': lap['LapTime'].total_seconds() if hasattr(lap['LapTime'], 'total_seconds') else lap['LapTime'],
                'sectors': {},
                'speeds': {
                    'max_speed': tel['Speed'].max() if 'Speed' in tel.columns else 0,
                    'avg_speed': tel['Speed'].mean() if 'Speed' in tel.columns else 0,
                    'min_speed': tel['Speed'].min() if 'Speed' in tel.columns else 0
                },
                'throttle': {
                    'max_throttle': tel['Throttle'].max() if 'Throttle' in tel.columns else 0,
                    'avg_throttle': tel['Throttle'].mean() if 'Throttle' in tel.columns else 0
                },
                'brake': {
                    'max_brake': tel['Brake'].max() if 'Brake' in tel.columns else 0,
                    'brake_points': len(tel[tel['Brake'] > 0]) if 'Brake' in tel.columns else 0
                }
            }
            
            # Sector times
            for i in range(1, 4):
                sector_key = f'Sector{i}Time'
                if sector_key in lap and not pd.isna(lap[sector_key]):
                    telemetry_data['sectors'][f'sector_{i}'] = lap[sector_key].total_seconds()
            
            return telemetry_data
            
        except Exception as e:
            logger.error(f"Error getting telemetry: {e}")
            return None

# Example usage and demonstration
async def main():
    """Demonstrate the enhanced lap predictor"""
    predictor = AdvancedLapPredictor()
    
    # Fetch session data
    print("Fetching session data...")
    session = await predictor.fetch_session_data(2024, 'Bahrain Grand Prix', 'R')
    
    if session:
        # Train model for a driver
        print("\nTraining model for Lewis Hamilton...")
        predictor.train_advanced_model(2024, 'Bahrain Grand Prix', 'R', 'HAM')
        
        # Perform real-time analysis
        print("\nPerforming real-time analysis...")
        analysis = predictor.real_time_analysis(session, 'HAM')
        if analysis:
            print(f"Driver: {analysis['driver']}")
            print(f"Best Lap: {analysis['best_lap']:.3f}s")
            print(f"Average Lap: {analysis['average_lap']:.3f}s")
            print(f"Consistency: {analysis['consistency']:.3f}s")
        
        # Compare drivers
        print("\nComparing drivers...")
        comparison = predictor.compare_drivers(session, ['HAM', 'VER', 'LEC'])
        for driver, data in comparison['drivers'].items():
            print(f"{driver}: Best {data['best_lap']:.3f}s, Avg {data['average_lap']:.3f}s")
        
        # Get telemetry data
        print("\nGetting telemetry data...")
        telemetry = predictor.get_driver_telemetry(session, 'HAM')
        if telemetry:
            print(f"Max Speed: {telemetry['speeds']['max_speed']:.1f} km/h")
            print(f"Average Speed: {telemetry['speeds']['avg_speed']:.1f} km/h")

if __name__ == "__main__":
    asyncio.run(main())