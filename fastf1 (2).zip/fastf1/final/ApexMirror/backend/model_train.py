import os
import pandas as pd
import numpy as np
from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_absolute_error
import joblib

MODEL_DIR = "../models"
DATA_DIR = "../data"
os.makedirs(MODEL_DIR, exist_ok=True)
os.makedirs(DATA_DIR, exist_ok=True)

MODEL_PATH = os.path.join(MODEL_DIR, "best_lap_model.joblib")


def load_data():
    """Combine all CSVs from data folder into one dataframe."""
    all_files = [os.path.join(DATA_DIR, f) for f in os.listdir(DATA_DIR) if f.endswith(".csv")]
    if not all_files:
        print("⚠️ No data found yet.")
        return pd.DataFrame(columns=["brake", "accel", "apex", "score"])
    dfs = [pd.read_csv(f) for f in all_files]
    df = pd.concat(dfs, ignore_index=True)
    df = df.dropna(subset=["brake", "accel", "apex", "score"])
    return df


def train_model():
    """Train or retrain the lap prediction model."""
    df = load_data()
    if df.empty:
        print("⚠️ No data available for training yet.")
        return None

    X = df[["brake", "accel", "apex"]]
    y = df["score"]

    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

    model = RandomForestRegressor(n_estimators=100, random_state=42)
    model.fit(X_train, y_train)

    preds = model.predict(X_test)
    mae = mean_absolute_error(y_test, preds)
    print(f"✅ Model trained. MAE = {mae:.4f}")

    joblib.dump(model, MODEL_PATH)
    print(f"💾 Model saved to {os.path.abspath(MODEL_PATH)}")
    return model


def load_model():
    """Load an existing model or train a new one if missing."""
    if os.path.exists(MODEL_PATH):
        print(f"📦 Loading existing model from {os.path.abspath(MODEL_PATH)}")
        return joblib.load(MODEL_PATH)
    else:
        print("🚀 No model found. Training a new one...")
        return train_model()


if __name__ == "__main__":
    train_model()
