import fastf1
import pandas as pd
import numpy as np
from sklearn.ensemble import RandomForestRegressor
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import mean_absolute_error, mean_squared_error
import warnings
warnings.filterwarnings('ignore')

class LapPredictor:
    def __init__(self):
        self.models = {}
        self.scalers = {}
        self.history_data = {}
        self.live_data = {}
        
    def fetch_historical_data(self, year, session_type, driver=None):
        """Fetch historical lap data for training"""
        try:
            session = fastf1.get_session(year, session_type, session_type)
            session.load()
            
            if driver:
                laps = session.laps.pick_driver(driver)
            else:
                laps = session.laps
                
            # Store historical data
            key = f"{year}_{session_type}_{driver if driver else 'all'}"
            self.history_data[key] = laps
            
            print(f"Fetched {len(laps)} historical laps for {key}")
            return laps
            
        except Exception as e:
            print(f"Error fetching historical data: {e}")
            return None
    
    def preprocess_lap_data(self, lap_data):
        """Preprocess lap data for model training"""
        features = []
        
        for lap in lap_data:
            if pd.isna(lap['LapTime']) or pd.isna(lap['LapNumber']):
                continue
                
            feature_dict = {
                'lap_number': lap['LapNumber'],
                'compound': self._encode_tyre(lap['Compound']),
                'track_temp': lap.get('TrackTemp', 25),
                'air_temp': lap.get('AirTemp', 25),
                'stint': lap.get('Stint', 1),
                'position': lap.get('Position', 10),
                'tyre_age': self._calculate_tyre_age(lap_data, lap),
            }
            
            # Add sector times if available
            for i in range(1, 4):
                sector_key = f'Sector{i}Time'
                if sector_key in lap and not pd.isna(lap[sector_key]):
                    feature_dict[f'sector_{i}'] = lap[sector_key].total_seconds()
                else:
                    feature_dict[f'sector_{i}'] = 0
            
            # Target variable: lap time in seconds
            if hasattr(lap['LapTime'], 'total_seconds'):
                target = lap['LapTime'].total_seconds()
            else:
                continue
                
            features.append((feature_dict, target))
        
        return features
    
    def _encode_tyre(self, compound):
        """Encode tyre compound to numerical value"""
        tyre_map = {'SOFT': 3, 'MEDIUM': 2, 'HARD': 1, 'INTERMEDIATE': 4, 'WET': 5}
        return tyre_map.get(compound, 0)
    
    def _calculate_tyre_age(self, laps, current_lap):
        """Calculate tyre age for a given lap"""
        try:
            stint = current_lap['Stint']
            current_lap_num = current_lap['LapNumber']
            
            # Find laps in same stint
            stint_laps = [lap for lap in laps if lap['Stint'] == stint]
            stint_laps = sorted(stint_laps, key=lambda x: x['LapNumber'])
            
            for i, lap in enumerate(stint_laps):
                if lap['LapNumber'] == current_lap_num:
                    return i + 1
                    
            return 1
        except:
            return 1
    
    def train_historical_model(self, year, session_type, driver=None):
        """Train model using historical data"""
        key = f"{year}_{session_type}_{driver if driver else 'all'}"
        
        if key not in self.history_data:
            self.fetch_historical_data(year, session_type, driver)
        
        laps = self.history_data[key]
        processed_data = self.preprocess_lap_data(laps)
        
        if len(processed_data) < 5:
            print("Not enough data for training")
            return None
        
        # Split features and targets
        X = [item[0] for item in processed_data]
        y = [item[1] for item in processed_data]
        
        # Convert to DataFrame
        X_df = pd.DataFrame(X)
        
        # Train-test split (use last few laps for testing)
        split_idx = int(0.8 * len(X_df))
        X_train, X_test = X_df[:split_idx], X_df[split_idx:]
        y_train, y_test = y[:split_idx], y[split_idx:]
        
        # Scale features
        scaler = StandardScaler()
        X_train_scaled = scaler.fit_transform(X_train)
        X_test_scaled = scaler.transform(X_test)
        
        # Train model
        model = RandomForestRegressor(n_estimators=100, random_state=42)
        model.fit(X_train_scaled, y_train)
        
        # Store model and scaler
        self.models[key] = model
        self.scalers[key] = scaler
        
        # Evaluate model
        train_score = model.score(X_train_scaled, y_train)
        test_score = model.score(X_test_scaled, y_test)
        
        print(f"Model trained for {key}")
        print(f"Train R²: {train_score:.3f}, Test R²: {test_score:.3f}")
        
        return model
    
    def predict_next_lap_historical(self, current_lap_data, year, session_type, driver=None):
        """Predict next lap time using historical model"""
        key = f"{year}_{session_type}_{driver if driver else 'all'}"
        
        if key not in self.models:
            print("Model not trained. Training now...")
            self.train_historical_model(year, session_type, driver)
        
        # Prepare input features
        input_features = self._prepare_prediction_features(current_lap_data)
        
        if input_features is None:
            return None
        
        # Scale features and predict
        scaler = self.scalers[key]
        model = self.models[key]
        
        input_scaled = scaler.transform([input_features])
        predicted_time_seconds = model.predict(input_scaled)[0]
        
        return pd.Timedelta(seconds=predicted_time_seconds)
    
    def predict_next_lap_live(self, recent_laps, current_conditions):
        """Predict next lap time using live data (simple moving average with conditions)"""
        if len(recent_laps) < 3:
            return None
        
        # Get recent lap times
        recent_times = []
        for lap in recent_laps[-5:]:  # Use last 5 laps
            if hasattr(lap['LapTime'], 'total_seconds'):
                recent_times.append(lap['LapTime'].total_seconds())
        
        if not recent_times:
            return None
        
        # Calculate weighted average (more weight to recent laps)
        weights = np.arange(1, len(recent_times) + 1)
        base_prediction = np.average(recent_times, weights=weights)
        
        # Adjust for conditions
        condition_adjustment = self._calculate_condition_adjustment(current_conditions)
        adjusted_prediction = base_prediction + condition_adjustment
        
        return pd.Timedelta(seconds=adjusted_prediction)
    
    def _calculate_condition_adjustment(self, conditions):
        """Calculate time adjustment based on track conditions"""
        adjustment = 0
        
        # Track temperature effect (simplified)
        track_temp = conditions.get('track_temp', 25)
        if track_temp > 40:
            adjustment += 0.3  # Hot track = slower
        elif track_temp < 20:
            adjustment += 0.2  # Cold track = slower
        
        # Tyre age effect
        tyre_age = conditions.get('tyre_age', 1)
        if tyre_age > 10:
            adjustment += (tyre_age - 10) * 0.1
        
        return adjustment
    
    def _prepare_prediction_features(self, lap_data):
        """Prepare features for prediction from current lap data"""
        try:
            features = {
                'lap_number': lap_data.get('LapNumber', 1) + 1,  # Next lap number
                'compound': self._encode_tyre(lap_data.get('Compound', 'MEDIUM')),
                'track_temp': lap_data.get('TrackTemp', 25),
                'air_temp': lap_data.get('AirTemp', 25),
                'stint': lap_data.get('Stint', 1),
                'position': lap_data.get('Position', 10),
                'tyre_age': lap_data.get('tyre_age', 1) + 1,
            }
            
            # Add sector times (use current lap's sectors as estimate)
            for i in range(1, 4):
                sector_key = f'Sector{i}Time'
                if sector_key in lap_data and not pd.isna(lap_data[sector_key]):
                    features[f'sector_{i}'] = lap_data[sector_key].total_seconds()
                else:
                    features[f'sector_{i}'] = 0
            
            return list(features.values())
            
        except Exception as e:
            print(f"Error preparing features: {e}")
            return None
    
    def compare_prediction_actual(self, predicted_lap, actual_lap):
        """Compare predicted lap time with actual lap time"""
        if predicted_lap is None or actual_lap is None:
            return None
        
        if hasattr(predicted_lap, 'total_seconds'):
            pred_seconds = predicted_lap.total_seconds()
        else:
            pred_seconds = predicted_lap
            
        if hasattr(actual_lap, 'total_seconds'):
            actual_seconds = actual_lap.total_seconds()
        else:
            actual_seconds = actual_lap
        
        difference = actual_seconds - pred_seconds
        absolute_error = abs(difference)
        percentage_error = (absolute_error / actual_seconds) * 100
        
        comparison = {
            'predicted': pd.Timedelta(seconds=pred_seconds),
            'actual': pd.Timedelta(seconds=actual_seconds),
            'difference': pd.Timedelta(seconds=difference),
            'absolute_error_seconds': absolute_error,
            'percentage_error': percentage_error,
            'is_faster': difference < 0  # Negative means actual was faster
        }
        
        return comparison
    
    def analyze_lap_performance(self, session_data, driver, prediction_method='historical'):
        """Complete lap performance analysis with predictions"""
        driver_laps = session_data.laps.pick_driver(driver)
        comparisons = []
        
        print(f"\nAnalyzing lap performance for {driver} using {prediction_method} method:")
        print("=" * 60)
        
        for i in range(2, len(driver_laps) - 1):  # Skip first and last lap
            current_lap = driver_laps.iloc[i]
            next_lap = driver_laps.iloc[i + 1]
            
            if pd.isna(current_lap['LapTime']) or pd.isna(next_lap['LapTime']):
                continue
            
            # Predict next lap
            if prediction_method == 'historical':
                predicted = self.predict_next_lap_historical(
                    current_lap, 2024, 'Race', driver
                )
            else:
                recent_laps = driver_laps.iloc[max(0, i-4):i+1]
                conditions = {
                    'track_temp': current_lap.get('TrackTemp', 25),
                    'tyre_age': self._calculate_tyre_age(driver_laps, current_lap)
                }
                predicted = self.predict_next_lap_live(recent_laps, conditions)
            
            if predicted is not None:
                comparison = self.compare_prediction_actual(predicted, next_lap['LapTime'])
                if comparison:
                    comparisons.append(comparison)
                    
                    print(f"Lap {current_lap['LapNumber'] + 1}: "
                          f"Predicted {predicted.total_seconds():.3f}s, "
                          f"Actual {next_lap['LapTime'].total_seconds():.3f}s, "
                          f"Error: {comparison['absolute_error_seconds']:.3f}s "
                          f"({comparison['percentage_error']:.1f}%)")
        
        if comparisons:
            self._print_analysis_summary(comparisons)
    
    def _print_analysis_summary(self, comparisons):
        """Print summary of prediction performance"""
        errors = [comp['absolute_error_seconds'] for comp in comparisons]
        avg_error = np.mean(errors)
        std_error = np.std(errors)
        best_pred = min(errors)
        worst_pred = max(errors)
        
        print("\n" + "=" * 60)
        print("PREDICTION PERFORMANCE SUMMARY:")
        print(f"Average Error: {avg_error:.3f} seconds")
        print(f"Error Std Dev: {std_error:.3f} seconds")
        print(f"Best Prediction: {best_pred:.3f} seconds")
        print(f"Worst Prediction: {worst_pred:.3f} seconds")
        print(f"Total Laps Analyzed: {len(comparisons)}")
        print("=" * 60)

# Example usage and demonstration
def main():
    # Initialize the lap predictor
    predictor = LapPredictor()
    
    # Fetch some sample data
    print("Fetching historical data...")
    session_2024 = fastf1.get_session(2024, 'Spanish Grand Prix', 'R')
    session_2024.load()
    
    # Train historical model
    print("\nTraining historical model...")
    predictor.train_historical_model(2024, 'Spanish Grand Prix', 'HAM')
    
    # Analyze lap performance
    print("\nPerforming lap analysis...")
    predictor.analyze_lap_performance(session_2024, 'HAM', 'historical')
    
    # Demonstrate live prediction
    print("\nDemonstrating live prediction...")
    ham_laps = session_2024.laps.pick_driver('HAM')
    
    if len(ham_laps) > 5:
        recent_laps = ham_laps.iloc[2:7]  # Get laps 3-7
        current_conditions = {
            'track_temp': ham_laps.iloc[6].get('TrackTemp', 25),
            'tyre_age': predictor._calculate_tyre_age(ham_laps, ham_laps.iloc[6])
        }
        
        live_prediction = predictor.predict_next_lap_live(recent_laps, current_conditions)
        actual_next_lap = ham_laps.iloc[7]['LapTime'] if len(ham_laps) > 7 else None
        
        if live_prediction and actual_next_lap:
            comparison = predictor.compare_prediction_actual(live_prediction, actual_next_lap)
            print(f"\nLive Prediction Example:")
            print(f"Predicted: {live_prediction.total_seconds():.3f}s")
            print(f"Actual: {actual_next_lap.total_seconds():.3f}s")
            print(f"Error: {comparison['absolute_error_seconds']:.3f}s")

if __name__ == "__main__":
    main()