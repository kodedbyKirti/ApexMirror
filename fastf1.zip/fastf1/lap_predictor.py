"""F1 Lap Predictor API - Machine Learning Model for Formula 1 Lap Time Prediction"""
import os
import warnings
from typing import Dict, List, Optional

import fastf1
import numpy as np
import pandas as pd
from fastf1.core import Laps
from flask import Flask, jsonify, request
from flask_cors import CORS
from sklearn.ensemble import RandomForestRegressor
from sklearn.preprocessing import StandardScaler

warnings.filterwarnings('ignore')

# Enable on-disk cache for speed and resilience
CACHE_DIR = os.path.join(os.path.dirname(__file__), 'ff1_cache')
try:
    os.makedirs(CACHE_DIR, exist_ok=True)
    fastf1.Cache.enable_cache(CACHE_DIR)
except Exception as e:
    print(f"Cache setup failed: {e}")


def session_label_to_code(label: str) -> str:
    label = (label or '').strip().lower()
    mapping = {
        'race': 'R', 'r': 'R',
        'qualifying': 'Q', 'q': 'Q',
        'practice 3': 'FP3', 'fp3': 'FP3',
        'practice 2': 'FP2', 'fp2': 'FP2',
        'practice 1': 'FP1', 'fp1': 'FP1',
        'sprint shootout': 'SS', 'sprint': 'S',
    }
    return mapping.get(label, label.upper() or 'R')


FEATURE_ORDER = [
    'lap_number', 'compound', 'track_temp', 'air_temp',
    'stint', 'position', 'tyre_age', 'sector_1', 'sector_2', 'sector_3'
]


class LapPredictor:
    def __init__(self):
        self.models: Dict[str, RandomForestRegressor] = {}
        self.scalers: Dict[str, StandardScaler] = {}
        self.history_data: Dict[str, Laps] = {}

    def _key(self, year: int, gp: str, session_code: str, driver: Optional[str]) -> str:
        return f"{year}_{gp}_{session_code}_{driver or 'all'}"

    def fetch_laps(self, year: int, gp: str, session_code: str, driver: Optional[str] = None) -> Optional[Laps]:
        try:
            sess = fastf1.get_session(year, gp, session_code)
            sess.load()
            laps = sess.laps.pick_driver(driver) if driver else sess.laps
            key = self._key(year, gp, session_code, driver)
            self.history_data[key] = laps
            return laps
        except Exception as e:
            print(f"Failed to load session: {e}")
            return None

    def _encode_tyre(self, compound: Optional[str]) -> int:
        tyre_map = {'SOFT': 3, 'MEDIUM': 2, 'HARD': 1, 'INTERMEDIATE': 4, 'WET': 5}
        return tyre_map.get((compound or '').upper(), 0)

    def _tyre_age_series(self, laps_df: pd.DataFrame) -> pd.Series:
        # Age within stint: 1,2,3,... per stint
        ages = (
            laps_df.sort_values('LapNumber')
            .groupby('Stint')['LapNumber']
            .transform(lambda s: s.rank(method='first').astype(int))
        )
        return ages.fillna(1)

    def preprocess_lap_data(self, laps: Laps) -> List[tuple]:
        if laps is None or len(laps) == 0:
            return []
        df = laps[[
            'LapNumber', 'LapTime', 'Compound', 'Stint', 'Position',
            'Sector1Time', 'Sector2Time', 'Sector3Time'
        ]].copy()
        df = df[~df['LapTime'].isna()]
        if df.empty:
            return []

        df['track_temp'] = 25.0  # fallback if no weather available
        df['air_temp'] = 25.0
        try:
            # If session weather is present, approximate by overall medians
            weather = laps.session.weather_data
            if weather is not None and not weather.empty:
                df['track_temp'] = float(weather['TrackTemp'].median())
                df['air_temp'] = float(weather['AirTemp'].median())
        except Exception:
            pass

        df['compound_num'] = df['Compound'].apply(self._encode_tyre)
        df['tyre_age'] = self._tyre_age_series(df)

        # Sector times to seconds
        for i in (1, 2, 3):
            col = f'Sector{i}Time'
            out = f'sector_{i}'
            df[out] = df[col].apply(lambda x: x.total_seconds() if pd.notna(x) else 0.0)

        rows = []
        for _, r in df.iterrows():
            feat = {
                'lap_number': int(r['LapNumber']),
                'compound': int(r['compound_num']),
                'track_temp': float(r['track_temp']),
                'air_temp': float(r['air_temp']),
                'stint': int(r['Stint']) if not pd.isna(r['Stint']) else 1,
                'position': int(r['Position']) if not pd.isna(r['Position']) else 10,
                'tyre_age': int(r['tyre_age']),
                'sector_1': float(r['sector_1']),
                'sector_2': float(r['sector_2']),
                'sector_3': float(r['sector_3']),
            }
            target = r['LapTime'].total_seconds()
            rows.append((feat, target))
        return rows

    def train(self, year: int, gp: str, session_code: str, driver: Optional[str] = None) -> Optional[RandomForestRegressor]:
        key = self._key(year, gp, session_code, driver)
        laps = self.history_data.get(key) or self.fetch_laps(year, gp, session_code, driver)
        if laps is None:
            return None

        data = self.preprocess_lap_data(laps)
        if len(data) < 10:
            print('Not enough data to train')
            return None
        X = pd.DataFrame([d[0] for d in data])[FEATURE_ORDER]
        y = np.array([d[1] for d in data])

        # chronological train/val split
        split = int(0.8 * len(X))
        X_train, X_val = X.iloc[:split], X.iloc[split:]
        y_train, y_val = y[:split], y[split:]

        scaler = StandardScaler()
        X_train_s = scaler.fit_transform(X_train)
        X_val_s = scaler.transform(X_val)

        model = RandomForestRegressor(n_estimators=300, max_depth=None, random_state=42, n_jobs=-1)
        model.fit(X_train_s, y_train)

        self.models[key] = model
        self.scalers[key] = scaler
        return model

    def _prepare_features_for_next(self, current_row: pd.Series) -> List[float]:
        feat = {
            'lap_number': int(current_row.get('LapNumber', 0)) + 1,
            'compound': self._encode_tyre(current_row.get('Compound', 'MEDIUM')),
            'track_temp': float(current_row.get('track_temp', 25.0)),
            'air_temp': float(current_row.get('air_temp', 25.0)),
            'stint': int(current_row.get('Stint', 1)),
            'position': int(current_row.get('Position', 10)),
            'tyre_age': int(current_row.get('tyre_age', 1)) + 1,
            'sector_1': float(current_row.get('Sector1Time', pd.Timedelta(seconds=0)).total_seconds() if pd.notna(current_row.get('Sector1Time')) else 0.0),
            'sector_2': float(current_row.get('Sector2Time', pd.Timedelta(seconds=0)).total_seconds() if pd.notna(current_row.get('Sector2Time')) else 0.0),
            'sector_3': float(current_row.get('Sector3Time', pd.Timedelta(seconds=0)).total_seconds() if pd.notna(current_row.get('Sector3Time')) else 0.0),
        }
        return [feat[k] for k in FEATURE_ORDER]

    def predict_next_historical(self, year: int, gp: str, session_code: str, driver: str) -> Optional[float]:
        key = self._key(year, gp, session_code, driver)
        model = self.models.get(key)
        scaler = self.scalers.get(key)
        if model is None or scaler is None:
            model = self.train(year, gp, session_code, driver)
            scaler = self.scalers.get(key)
        laps = self.history_data.get(key) or self.fetch_laps(year, gp, session_code, driver)
        if laps is None or model is None or scaler is None:
            return None
        df = laps
        df = df[~df['LapTime'].isna()].sort_values('LapNumber')
        if df.empty:
            return None
        last_row = df.iloc[-1]
        feats = self._prepare_features_for_next(last_row)
        pred = model.predict(scaler.transform([feats]))[0]
        return float(pred)

    def predict_next_live(self, laps: Laps) -> Optional[float]:
        if laps is None or len(laps) < 3:
            return None
        df = laps[~laps['LapTime'].isna()].sort_values('LapNumber').tail(5)
        if df.empty:
            return None
        times = df['LapTime'].apply(lambda x: x.total_seconds()).to_numpy()
        weights = np.arange(1, len(times) + 1)
        return float(np.average(times, weights=weights))

    @staticmethod
    def laps_to_records(laps: Laps) -> List[dict]:
        if laps is None or len(laps) == 0:
            return []
        df = laps.sort_values('LapNumber').copy()
        out = []
        for _, r in df.iterrows():
            rec = {
                'LapNumber': int(r['LapNumber']) if not pd.isna(r['LapNumber']) else None,
                'LapTime': (r['LapTime'].total_seconds() if pd.notna(r['LapTime']) else None),
                'Sector1Time': (r['Sector1Time'].total_seconds() if pd.notna(r['Sector1Time']) else None),
                'Sector2Time': (r['Sector2Time'].total_seconds() if pd.notna(r['Sector2Time']) else None),
                'Sector3Time': (r['Sector3Time'].total_seconds() if pd.notna(r['Sector3Time']) else None),
                'Compound': (str(r['Compound']) if pd.notna(r['Compound']) else None),
                'Stint': int(r['Stint']) if not pd.isna(r['Stint']) else None,
                'Position': int(r['Position']) if not pd.isna(r['Position']) else None,
            }
            out.append(rec)
        return out


predictor = LapPredictor()
app = Flask(__name__)
CORS(app)


@app.get('/api/meta')
def api_meta():
    year = int(request.args.get('year', 2024))
    gp = request.args.get('gp', 'Spanish Grand Prix')
    session_label = request.args.get('session', 'Race')
    code = session_label_to_code(session_label)
    try:
        sess = fastf1.get_session(year, gp, code)
        sess.load()
        drivers = sorted(set(sess.laps['Driver'].dropna().unique().tolist()))
        return jsonify({
            'year': year, 'gp': gp, 'session': code,
            'drivers': drivers,
            'laps_total': int(sess.laps['LapNumber'].max()) if len(sess.laps) else 0
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 400


@app.get('/api/laps')
def api_laps():
    year = int(request.args.get('year', 2024))
    gp = request.args.get('gp', 'Spanish Grand Prix')
    session_label = request.args.get('session', 'Race')
    driver = request.args.get('driver')
    code = session_label_to_code(session_label)
    laps = predictor.fetch_laps(year, gp, code, driver)
    return jsonify({'laps': predictor.laps_to_records(laps or Laps())})


@app.get('/api/predict-next')
def api_predict_next():
    year = int(request.args.get('year', 2024))
    gp = request.args.get('gp', 'Spanish Grand Prix')
    session_label = request.args.get('session', 'Race')
    driver = request.args.get('driver', 'HAM')
    method = request.args.get('method', 'historical')
    code = session_label_to_code(session_label)

    laps = predictor.fetch_laps(year, gp, code, driver)
    if laps is None or len(laps) == 0:
        return jsonify({'error': 'No laps available'}), 400

    if method == 'live':
        pred = predictor.predict_next_live(laps)
    else:
        pred = predictor.predict_next_historical(year, gp, code, driver)

    if pred is None:
        return jsonify({'error': 'Prediction unavailable'}), 400

    # Provide simple confidence proxy from RF variance (std of tree preds)
    key = predictor._key(year, gp, code, driver)
    model = predictor.models.get(key)
    scaler = predictor.scalers.get(key)
    conf = None
    if method != 'live' and model is not None and scaler is not None:
        df = laps[~laps['LapTime'].isna()].sort_values('LapNumber')
        last_row = df.iloc[-1]
        feats = np.array(predictor._prepare_features_for_next(last_row)).reshape(1, -1)
        feats = scaler.transform(feats)
        tree_preds = np.array([t.predict(feats)[0] for t in model.estimators_])
        conf = float(max(0.0, 100.0 - np.std(tree_preds) * 50.0))

    return jsonify({'predicted_seconds': float(pred), 'confidence': conf})


@app.get('/api/compare')
def api_compare():
    year = int(request.args.get('year', 2024))
    gp = request.args.get('gp', 'Spanish Grand Prix')
    session_label = request.args.get('session', 'Race')
    driver_a = request.args.get('driverA', 'HAM')
    driver_b = request.args.get('driverB', 'VER')
    code = session_label_to_code(session_label)

    laps_a = predictor.fetch_laps(year, gp, code, driver_a) or Laps()
    laps_b = predictor.fetch_laps(year, gp, code, driver_b) or Laps()

    rec_a = predictor.laps_to_records(laps_a)
    rec_b = predictor.laps_to_records(laps_b)

    # Build lap-aligned comparison
    by_lap_a = {r['LapNumber']: r for r in rec_a if r['LapNumber'] is not None}
    by_lap_b = {r['LapNumber']: r for r in rec_b if r['LapNumber'] is not None}
    laps_union = sorted(set(by_lap_a.keys()) | set(by_lap_b.keys()))
    comp = []
    for ln in laps_union:
        a = by_lap_a.get(ln)
        b = by_lap_b.get(ln)
        comp.append({
            'LapNumber': ln,
            'A': a['LapTime'] if a else None,
            'B': b['LapTime'] if b else None,
            'Delta': (None if (a is None or b is None or a['LapTime'] is None or b['LapTime'] is None)
                      else float(b['LapTime'] - a['LapTime']))
        })

    return jsonify({'driverA': driver_a, 'driverB': driver_b, 'comparison': comp})


if __name__ == '__main__':
    # Run API server
    port = int(os.environ.get('PORT', '8000'))
    print(f"Starting F1 Lap Predictor API on http://127.0.0.1:{port}")
    app.run(host='0.0.0.0', port=port, debug=False, threaded=True)
