# backend/model.py
import pandas as pd
from sklearn.ensemble import RandomForestRegressor
import joblib
import os

def train_model():
    df = pd.read_csv("data/laps.csv")
    X = df[['brake_offset', 'accel_offset', 'missed_apex']]
    y = df['lap_time']
    
    model = RandomForestRegressor(n_estimators=100, random_state=42)
    model.fit(X, y)
    
    os.makedirs("models", exist_ok=True)
    joblib.dump(model, "models/bestlap_model.pkl")
    print("✅ Model trained and saved to models/bestlap_model.pkl")

if __name__ == "__main__":
    train_model()
