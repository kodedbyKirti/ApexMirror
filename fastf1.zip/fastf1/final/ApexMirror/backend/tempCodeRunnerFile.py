from flask import Flask, request, jsonify
from flask_cors import CORS
import os
import pandas as pd
import datetime
import random
import pickle

app = Flask(__name__)
CORS(app)

# === Directories ===
RACE_DATA_DIR = "race_data"
HISTORY_DIR = "race_history"
MODEL_PATH = "models/bestlap_model.pkl"

os.makedirs(RACE_DATA_DIR, exist_ok=True)
os.makedirs(HISTORY_DIR, exist_ok=True)

# === Load ML model if available ===
model = None
if os.path.exists(MODEL_PATH):
    try:
        with open(MODEL_PATH, "rb") as f:
            model = pickle.load(f)
        print("✅ ML model loaded successfully!")
    except Exception as e:
        print("⚠️ Could not load model:", e)
else:
    print("⚠️ No model found. Using fallback logic.")


# === Scoring logic ===
def compute_lap_score(brake, accel, apex):
    if model:
        try:
            pred = model.predict([[brake, accel, apex]])
            return float(pred[0])
        except Exception:
            pass
    return round(100 - (abs(brake) * 3 + abs(accel) * 2 + abs(apex) * 0.5) + random.uniform(-1, 1), 2)


# === ROUTE: Predict Lap Analysis ===
@app.route("/predict", methods=["POST"])
def predict():
    data = request.get_json()
    if not data or "laps" not in data:
        return jsonify({"error": "Invalid input"}), 400

    driver_name = data.get("driver_name", "unknown").strip().lower().replace(" ", "_")
    laps = data["laps"]

    lap_results = []
    total_score = 0

    for lap in laps:
        score = compute_lap_score(lap["brake"], lap["accel"], lap["apex"])
        lap["lap_score"] = score
        lap_results.append(lap)
        total_score += score

    avg_score = round(total_score / len(laps), 2)
    trend = "Improving" if avg_score > 85 else "Needs Practice"

    # Save lap data to CSV
    timestamp = datetime.datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
    filename = f"{driver_name}_{timestamp}.csv"
    file_path = os.path.join(RACE_DATA_DIR, filename)
    df = pd.DataFrame(lap_results)
    df.to_csv(file_path, index=False)

    # Log to history
    history_entry = {
        "display_name": driver_name,
        "lap_score": avg_score,
        "trend": trend,
        "file_saved": filename,
        "timestamp": timestamp
    }

    history_path = os.path.join(HISTORY_DIR, f"{driver_name}_history.csv")
    if os.path.exists(history_path):
        df_old = pd.read_csv(history_path)
        df_old = pd.concat([df_old, pd.DataFrame([history_entry])])
    else:
        df_old = pd.DataFrame([history_entry])
    df_old.to_csv(history_path, index=False)

    print(f"✅ Saved: {filename}")

    return jsonify({
        "driver": driver_name,
        "lap_score": avg_score,
        "trend": trend,
        "file_saved": filename
    })


# === ROUTE: Get Driver History ===
@app.route("/history", methods=["GET"])
def history():
    driver = request.args.get("driver", "").strip().lower().replace(" ", "_")
    if not driver:
        return jsonify({"error": "Driver name required"}), 400

    history_path = os.path.join(HISTORY_DIR, f"{driver}_history.csv")
    if not os.path.exists(history_path):
        return jsonify({"history": []})

    df = pd.read_csv(history_path)
    history_list = df.to_dict(orient="records")
    return jsonify({"history": history_list})


# === ROUTE: Generate Perfect Lap (with source info) ===
@app.route("/perfect-lap", methods=["GET"])
def perfect_lap():
    driver = request.args.get("driver", "").strip().lower().replace(" ", "_")
    if not driver:
        return jsonify({"error": "Driver name required"}), 400

    driver_files = [f for f in os.listdir(RACE_DATA_DIR) if f.startswith(driver)]
    if not driver_files:
        return jsonify({"error": "No laps found for this driver"}), 404

    all_data = []
    for f in driver_files:
        df = pd.read_csv(os.path.join(RACE_DATA_DIR, f))
        df["source_file"] = f
        try:
            time_part = "_".join(f.split("_")[1:]).replace(".csv", "")
        except IndexError:
            time_part = "unknown"
        df["source_time"] = time_part
        all_data.append(df)

    df_all = pd.concat(all_data, ignore_index=True)

    # Add scores if missing
    if "lap_score" not in df_all.columns:
        df_all["lap_score"] = df_all.apply(lambda r: compute_lap_score(r["brake"], r["accel"], r["apex"]), axis=1)

    # Find best turn entries
    best_indices = df_all.groupby("turn")["lap_score"].idxmax()
    perfect_lap_df = df_all.loc[best_indices, ["turn", "brake", "accel", "apex", "lap_score", "source_file", "source_time"]]
    perfect_lap_df = perfect_lap_df.sort_values(by="turn")

    perfect_filename = f"{driver}_perfectlap.csv"
    perfect_lap_df.to_csv(os.path.join(RACE_DATA_DIR, perfect_filename), index=False)

    perfect_lap_data = perfect_lap_df.to_dict(orient="records")

    print(f"🏁 Perfect lap generated for {driver}: {perfect_filename}")

    return jsonify({
        "driver": driver,
        "perfect_lap": perfect_lap_data,
        "file_saved": perfect_filename
    })


# === Root test ===
@app.route("/")
def home():
    return jsonify({"message": "Apex Mirror backend running successfully!"})


if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5000, debug=True)
